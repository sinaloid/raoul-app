<div>
    <span class="sm-title-2 font-weight-bold text-uppercase">
        Rencontres Cinématographiques de Sya (RECIS)
    </span>
    <p class="mt-3">
        Les RECIS sont un projet de festival qui a pour but de faire la promotion des cinémas burkinabé 
        et des diasporas africaines et des afros descendants et des pays du Sahel. 
    </p>
</div>
<p>
    Les RECIS se veulent être un cadre de rencontre et d’échanges entre les cinéastes burkinabé, 
    de la diaspora africaine et afro descendante, c'est au aussi un lieu où le cinéma burkinabé sera primé. 
    En effet, il n’y a pas un évènement culturel national qui fait la promotion et prime le cinéma burkinabé. 
    Les RECIS seront cet endroit à Bobo Dioulasso, où le cinéma burkinabé sera célébré. 
</p>
<p>
    Aussi, les RECIS ambitionnent de rapprocher davantage le cinéma burkinabé et de la diaspora africaine 
    et afro descendant de son public. Dans un contexte où les salles de cinéma sont quasiment inexistantes, 
    il est impératif pour la survie même du cinéma africain et burkinabé en particulier, de s'enraciner 
    dans les quartiers populaires d'où ce cinéma tire sa sève vivifiante. 
</p>
<P>
    Le concept que nous proposons est novateur à plusieurs niveaux :
    <ul class="px-5">
        <li>D'abord dans son approche : donner la possibilité au cinéma Burkinabè d’aller à la rencontre de son public en sortant des cadres de projection traditionnels</li>
        <li>Ensuite, que le cinéma de la diaspora africaine et des afro-descendants soit rendu accessible à ce public, </li>
        <li>Enfin que le cinéma mette en lumière d'autres sphères de la création artistique telle que la musique. </li>
    </ul>
</P>