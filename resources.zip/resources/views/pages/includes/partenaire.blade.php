<div>
    <span class="sm-title-2 font-weight-bold text-uppercase">
        Partenaires
    </span>
    <div class="col-4 col-md-2 my-4">
        <img width="100%" src="{{ asset('assets/img/partenaires/p-1.png') }}" alt="">
    </div>
</div>