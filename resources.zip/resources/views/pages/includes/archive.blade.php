<div>
    <span class="sm-title-2  font-weight-bold text-uppercase">archives</span>
    @if (1 == 2)
        <p class="mt-3">
            Lorem ipsum dolor sit, amet consectetur adipisicing elit.
            Sed, cumque sapiente repudiandae ducimus atque veritatis
            quisquam, ad reprehenderit tenetur fuga, fugit alias excepturi!
            Dolore harum fuga cumque voluptatibus possimus? Blanditiis.
        </p>
    @endif

</div>
@if (1 == 2)
    <p>
        Lorem ipsum dolor sit, amet consectetur adipisicing elit.
        Sed, cumque sapiente repudiandae ducimus atque veritatis
        quisquam, ad reprehenderit tenetur fuga, fugit alias excepturi!
        Dolore harum fuga cumque voluptatibus possimus? Blanditiis.
        Lorem ipsum dolor sit, amet consectetur adipisicing elit.
        Sed, cumque sapiente repudiandae ducimus atque veritatis
        quisquam, ad reprehenderit tenetur fuga, fugit alias excepturi!
        Dolore harum fuga cumque voluptatibus possimus? Blanditiis.
    </p>
    <p>
        Lorem ipsum dolor sit, amet consectetur adipisicing elit.
        Sed, cumque sapiente repudiandae ducimus atque veritatis
        quisquam, ad reprehenderit tenetur fuga, fugit alias excepturi!
        Dolore harum fuga cumque voluptatibus possimus? Blanditiis.
    </p>
    <p>
        Lorem ipsum dolor sit, amet consectetur adipisicing elit.
        Sed, cumque sapiente repudiandae ducimus atque veritatis
        quisquam, ad reprehenderit tenetur fuga, fugit alias excepturi!
        Dolore harum fuga cumque voluptatibus possimus? Blanditiis.
        Lorem ipsum dolor sit, amet consectetur adipisicing elit.
        Sed, cumque sapiente repudiandae ducimus atque veritatis
        quisquam, ad reprehenderit tenetur fuga, fugit alias excepturi!
        Dolore harum fuga cumque voluptatibus possimus? Blanditiis.
        Lorem ipsum dolor sit, amet consectetur adipisicing elit.
        Sed, cumque sapiente repudiandae ducimus atque veritatis
        quisquam, ad reprehenderit tenetur fuga, fugit alias excepturi!
        Dolore harum fuga cumque voluptatibus possimus? Blanditiis.
        Lorem ipsum dolor sit, amet consectetur adipisicing elit.
        Sed, cumque sapiente repudiandae ducimus atque veritatis
        quisquam, ad reprehenderit tenetur fuga, fugit alias excepturi!
        Dolore harum fuga cumque voluptatibus possimus? Blanditiis.
    </p>
@endif
