<div>
    <span class="sm-title-2 font-weight-bold text-uppercase">
        Organisateurs/trices
    </span>
    <p class="mt-3">
        <ul>
            <li><span class="font-weight-bold text-uppercase">Président</span>
                <ul class="px-5 py-2">
                    <li>BAYALA ERIC</li>
                </ul>
            </li>
            <li><span class="font-weight-bold text-uppercase">Sécretaire Général</span>
                <ul class="px-5 py-2">
                    <li>SANON BAKARY</li>
                </ul>
            </li>
            <li><span class="font-weight-bold text-uppercase">Trésorière Générale</span>
                <ul class="px-5 py-2">
                    <li>IMA VERONIQUE</li>
                </ul>
            </li>
        </ul>
    </p>
</div>