@extends('template.app')

@section('page_title')
    événements
@endsection

@section('content')
    <div class="row bannier">
        <div class="col-12 col-md-10 col-lg-8 mx-auto">
            <div class="col-12 py-5">
                <h1 class="title-1 font-weight-bold text-white pt-2 text-capitalize animate__animated animate__wobble">événements</h1>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12 col-md-10 col-lg-8 mx-auto mt-5 p-3 text-center">
            <span class="title-2 importante font-weight-bold text-uppercase">événements à venir</span>
        </div>
        <div class="col-12 col-md-10 col-lg-8 mx-auto p-3  d-flex flex-wrap">
            <div class="col-12 col-lg-4">
                <img width="100%" src="{{ asset('assets/img/even1.jpeg') }}" alt="">
            </div>
            <div class="col-12 col-lg-8">
                <div class="card p-3 " style="height: 100%">
                    <h2 class="sm-title-1 font-weight-bold">Première édition des RECIS</h2>
                    <span class="sm-title-3 font-weight-bold d-block my-2">06/12/2022 - Projection - Institut français Bobo Dioulasso</span>
                        Cette première édition se tiendra à l’institut français de Bobo Dioulasso du 6 au 10 décembre 2022 avec 
                        le programme suivant du mardi 6 au jeudi 8 des projections des films à l’institut français. 
                        Et à partir du 8 au 10 décembre nous continuerons le festival avec des projections de films en 
                        plein air dans la ville de Bobo-Dioulasso et dans les communes environnantes et terminer par une 
                        clôture de remise de prix suivie d’un concert avec un artiste de la sous-région ou du Burkina Faso
                    <div>
                        <a class="importante font-weight-bold" href="#">En savoir plus</a>
                    </div>
                </div>
            </div>
        </div>
        @if (1 == 2)
            <div class="col-12 col-md-10 col-lg-8 mx-auto p-3  d-flex flex-wrap">
                <div class="col-12 col-lg-4">
                    <img width="100%" src="{{ asset('assets/img/even2.jpeg') }}" alt="">
                </div>
                <div class="col-12 col-lg-8">
                    <div class="card p-3 " style="height: 100%">
                        <h2 class="sm-title-1 font-weight-bold">Lorem, ipsum dolor sit amet consectetur</h2>
                        <span class="sm-title-3 font-weight-bold d-block my-2">10/05/2022 - Projection - Maison de la
                            culture</span>
                        Lorem, ipsum dolor sit amet consectetur
                        adipisicing elit. Veniam mollitia voluptatibus t
                        otam repellendus possimus laboriosam nemo.
                        Labore eum molestias suscipit ratione animi!
                        Voluptatibus, doloribus iure sit excepturi commodi
                        fuga officiis! Lorem, ipsum dolor sit amet consectetur
                        adipisicing elit. Veniam mollitia voluptatibus t
                        otam repellendus possimus laboriosam nemo.
                        Labore eum molestias suscipit ratione animi!
                        Voluptatibus, doloribus iure sit excepturi commodi
                        fuga officiis!
                        <div>
                            <a class="importante font-weight-bold" href="#">En savoir plus</a>
                        </div>
                    </div>
                </div>
            </div>
        @endif
    </div>
    @if (1 == 2)
    <div class="row">
        <div class="col-12 col-md-10 col-lg-8 mx-auto mt-2 p-3 text-center">
            <span class="title-2 importante font-weight-bold text-uppercase">événements à passé</span>
        </div>
        <div class="col-12 col-md-10 col-lg-8 mx-auto p-3  d-flex flex-wrap">
            <div class="col-12 col-lg-4">
                <img width="100%" src="{{ asset('assets/img/even1.jpeg') }}" alt="">
            </div>
            <div class="col-12 col-lg-8">
                <div class="card p-3 " style="height: 100%">
                    <h2 class="sm-title-1 font-weight-bold">Lorem, ipsum dolor sit amet consectetur</h2>
                    <span class="sm-title-3 font-weight-bold d-block my-2">10/05/2022 - Projection - Maison de la
                        culture</span>
                    Lorem, ipsum dolor sit amet consectetur
                    adipisicing elit. Veniam mollitia voluptatibus t
                    otam repellendus possimus laboriosam nemo.
                    Labore eum molestias suscipit ratione animi!
                    Voluptatibus, doloribus iure sit excepturi commodi
                    fuga officiis! Lorem, ipsum dolor sit amet consectetur
                    adipisicing elit. Veniam mollitia voluptatibus t
                    otam repellendus possimus laboriosam nemo.
                    Labore eum molestias suscipit ratione animi!
                    Voluptatibus, doloribus iure sit excepturi commodi
                    fuga officiis!
                    <div>
                        <a class="importante font-weight-bold" href="#">En savoir plus</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-12 col-md-10 col-lg-8 mx-auto p-3  d-flex flex-wrap">
            <div class="col-12 col-lg-4">
                <img width="100%" src="{{ asset('assets/img/even2.jpeg') }}" alt="">
            </div>
            <div class="col-12 col-lg-8">
                <div class="card p-3 " style="height: 100%">
                    <h2 class="sm-title-1 font-weight-bold">Lorem, ipsum dolor sit amet consectetur</h2>
                    <span class="sm-title-3 font-weight-bold d-block my-2">10/05/2022 - Projection - Maison de la
                        culture</span>
                    Lorem, ipsum dolor sit amet consectetur
                    adipisicing elit. Veniam mollitia voluptatibus t
                    otam repellendus possimus laboriosam nemo.
                    Labore eum molestias suscipit ratione animi!
                    Voluptatibus, doloribus iure sit excepturi commodi
                    fuga officiis! Lorem, ipsum dolor sit amet consectetur
                    adipisicing elit. Veniam mollitia voluptatibus t
                    otam repellendus possimus laboriosam nemo.
                    Labore eum molestias suscipit ratione animi!
                    Voluptatibus, doloribus iure sit excepturi commodi
                    fuga officiis!
                    <div>
                        <a class="importante font-weight-bold" href="#">En savoir plus</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    @endif
@endsection
