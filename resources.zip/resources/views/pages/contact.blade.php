@extends('template.app')

@section('script')
    <script src="https://smtpjs.com/v3/smtp.js"></script> 
@endsection

@section('page_title')
    Contact
@endsection

@section('content')
    <div class="row bannier">
        <div class="col-12 col-md-10 col-lg-8 mx-auto">
            <div class="col-12 py-5">
                <h1 class="title-1 font-weight-bold text-white pt-2 animate__animated animate__wobble">Contactez nous ici</h1>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12 col-md-10 col-lg-8 mx-auto p-3  d-flex flex-wrap">
            <div class="col-12 col-lg-4">
                <span class="sm-title-1 d-block font-weight-bold">Contact</span>
                <span class="font-weight-bold">Rencontres Cinématographiques de Sya (RECIS)</span>
                <p>
                    <span class="font-weight-bold">Sise:</span> Secteur 25 Bobo-Dioulasso <br />
                    <span class="font-weight-bold">Tel:</span> +226 70 15 67 10
                </p>
                <div class="p-2" style="width: fit-content">
                    <a class="mx-2" href="#"><i class="fa-brands fa-facebook fa-2xl"
                            style="color: #4267B2"></i></a>
                    <a class="mx-2" href="#"><i class="fa-brands fa-instagram fa-2xl"></i></a>
                    <a class="mx-2" href="#"><i class="fa-brands fa-whatsapp fa-2xl"
                            style="color: #25D366 !important"></i></a>
                </div>
            </div>
            <div class="col-12 col-lg-8">
                <div class="card p-3 ">
                    <form action="#">
                        <div class="form-group">
                          <label for="email">Adresse Email:</label>
                          <input type="email" class="form-control" placeholder="Entrer votre email" id="email">
                        </div>
                        <div class="form-group">
                          <label for="pwd">Nom Prenom:</label>
                          <input type="text" class="form-control" placeholder="Entrer votre nom et prenom" id="pwd">
                        </div>
                        <div class="form-group">
                            <label for="comment">Commentaire :</label>
                            <textarea class="form-control" rows="5" id="comment" placeholder="Entrer votre message"></textarea>
                        </div> 
                        <button type="submit" class="btn btn-recis">Envoyer</button>
                    </form> 
                </div>
            </div>
        </div>
    </div>
@endsection
