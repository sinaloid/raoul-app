@extends('template.app')

@section('page_title')
    Photos
@endsection

@section('content')
    <div class="row bannier">
        <div class="col-12 col-md-10 col-lg-8 mx-auto">
            <div class="col-12 py-5">
                <h1 class="title-1 font-weight-bold text-white pt-2 animate__animated animate__wobble">Photos des RECIS</h1>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12 col-md-10 col-lg-8 mx-auto mt-5 p-3 text-center">
            <span class="title-2 importante font-weight-bold text-uppercase ">Photos de la 1ère édition</span>
        </div>
        <div class="col-12 col-md-10 col-lg-8 mx-auto p-3  d-flex flex-wrap">
            <div class="col-12">
                <span class="sm-title-1 font-weight-bold">1ère journée</span>
            </div>
            <div class="col-12 col-sm-6 col-md-4 col-lg-3 py-3">
                <img width="100%" src="{{ asset('assets/img/even1.jpeg') }}" alt="">
            </div>
            <div class="col-12 col-sm-6 col-md-4 col-lg-3 py-3">
                <img width="100%" src="{{ asset('assets/img/even2.jpeg') }}" alt="">
            </div>
            <div class="col-12 col-sm-6 col-md-4 col-lg-3 py-3">
                <img width="100%" src="{{ asset('assets/img/even2.jpeg') }}" alt="">
            </div>
            <div class="col-12 col-sm-6 col-md-4 col-lg-3 py-3">
                <img width="100%" src="{{ asset('assets/img/even2.jpeg') }}" alt="">
            </div> 
            <div class="col-12 col-sm-6 col-md-4 col-lg-3 py-3">
                <img width="100%" src="{{ asset('assets/img/even1.jpeg') }}" alt="">
            </div>
            <div class="col-12 col-sm-6 col-md-4 col-lg-3 py-3">
                <img width="100%" src="{{ asset('assets/img/even2.jpeg') }}" alt="">
            </div>
            <div class="col-12 col-sm-6 col-md-4 col-lg-3 py-3">
                <img width="100%" src="{{ asset('assets/img/even2.jpeg') }}" alt="">
            </div>
            <div class="col-12 col-sm-6 col-md-4 col-lg-3 py-3">
                <img width="100%" src="{{ asset('assets/img/even2.jpeg') }}" alt="">
            </div> 
        </div>
        <div class="col-12 col-md-10 col-lg-8 mx-auto p-3  d-flex flex-wrap">
            <div class="col-12">
                <span class="sm-title-1 font-weight-bold">2ème journée</span>
            </div>
            <div class="col-12 col-sm-6 col-md-4 col-lg-3 py-3">
                <img width="100%" src="{{ asset('assets/img/even1.jpeg') }}" alt="">
            </div>
            <div class="col-12 col-sm-6 col-md-4 col-lg-3 py-3">
                <img width="100%" src="{{ asset('assets/img/even2.jpeg') }}" alt="">
            </div>
            <div class="col-12 col-sm-6 col-md-4 col-lg-3 py-3">
                <img width="100%" src="{{ asset('assets/img/even2.jpeg') }}" alt="">
            </div>
            <div class="col-12 col-sm-6 col-md-4 col-lg-3 py-3">
                <img width="100%" src="{{ asset('assets/img/even2.jpeg') }}" alt="">
            </div> 
            <div class="col-12 col-sm-6 col-md-4 col-lg-3 py-3">
                <img width="100%" src="{{ asset('assets/img/even1.jpeg') }}" alt="">
            </div>
            <div class="col-12 col-sm-6 col-md-4 col-lg-3 py-3">
                <img width="100%" src="{{ asset('assets/img/even2.jpeg') }}" alt="">
            </div>
            <div class="col-12 col-sm-6 col-md-4 col-lg-3 py-3">
                <img width="100%" src="{{ asset('assets/img/even2.jpeg') }}" alt="">
            </div>
            <div class="col-12 col-sm-6 col-md-4 col-lg-3 py-3">
                <img width="100%" src="{{ asset('assets/img/even2.jpeg') }}" alt="">
            </div> 
        </div>
        <div class="col-12 col-md-10 col-lg-8 mx-auto p-3  d-flex flex-wrap">
            <div class="col-12">
                <span class="sm-title-1 font-weight-bold">3ème journée</span>
            </div>
            <div class="col-12 col-sm-6 col-md-4 col-lg-3 py-3">
                <img width="100%" src="{{ asset('assets/img/even1.jpeg') }}" alt="">
            </div>
            <div class="col-12 col-sm-6 col-md-4 col-lg-3 py-3">
                <img width="100%" src="{{ asset('assets/img/even2.jpeg') }}" alt="">
            </div>
            <div class="col-12 col-sm-6 col-md-4 col-lg-3 py-3">
                <img width="100%" src="{{ asset('assets/img/even2.jpeg') }}" alt="">
            </div>
            <div class="col-12 col-sm-6 col-md-4 col-lg-3 py-3">
                <img width="100%" src="{{ asset('assets/img/even2.jpeg') }}" alt="">
            </div> 
            <div class="col-12 col-sm-6 col-md-4 col-lg-3 py-3">
                <img width="100%" src="{{ asset('assets/img/even1.jpeg') }}" alt="">
            </div>
            <div class="col-12 col-sm-6 col-md-4 col-lg-3 py-3">
                <img width="100%" src="{{ asset('assets/img/even2.jpeg') }}" alt="">
            </div>
            <div class="col-12 col-sm-6 col-md-4 col-lg-3 py-3">
                <img width="100%" src="{{ asset('assets/img/even2.jpeg') }}" alt="">
            </div>
            <div class="col-12 col-sm-6 col-md-4 col-lg-3 py-3">
                <img width="100%" src="{{ asset('assets/img/even2.jpeg') }}" alt="">
            </div> 
        </div>
    </div>
@endsection
