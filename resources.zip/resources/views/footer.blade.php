        <footer class="row pt-3 mt-5 bg-dark text-white">
            <div class="col-12 col-md-10 mx-auto d-flex flex-wrap">
                <div class="col-12 col-sm-4 pb-3">
                    <div class="mx-auto" style="width: fit-content">
                        <span class="font-weight-bold sm-title-2 text-center w-100 d-block">Contactez Nous</span>
                        <div>Sise:Secteur 25 Bobo-Dioulasso</div>
                        <div>Tel: +226 70 15 67 10</div>
                        <div>Email: recis@gmail.com</div>
                    </div>
                </div>
                <div class="col-12 col-sm-4 pb-3">
                    <div class="mx-auto" style="width: fit-content">
                        <span class="font-weight-bold sm-title-2 text-center w-100 d-block">Autres Informations</span>
                        <div>Lorem ipsum dolor,eum sit amet</div>
                        <div>Minima sapiente eum quas eum</div>
                    </div>
                </div>
                <div class="col-12 col-sm-4 pb-3">
                    <div class="bg-white p-2 mx-auto" style="width: fit-content">
                        <a class="mx-2" href="#"><i class="fa-brands fa-facebook fa-2xl"
                                style="color: #4267B2"></i></a>
                        <a class="mx-2" href="#"><i class="fa-brands fa-instagram fa-2xl"></i></a>
                        <a class="mx-2" href="#"><i class="fa-brands fa-whatsapp fa-2xl"
                                style="color: #25D366 !important"></i></a>
                    </div>
                </div>
            </div>
            <div class="col-12 text-center">
                © 2022 RECIS, Tout droits réservé
            </div>

        </footer>
