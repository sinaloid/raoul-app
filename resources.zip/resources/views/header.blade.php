<div class="container-fluid p-0 bg-recis">
    <div class="col-12 col-md-10 col-lg-8 d-flex">
        <div class="col-4 col-md-3 col-lg-2 p-0">
            <a class="navbar-brand py-0" href="{{ route('accueil') }}">
                <img src="{{ asset('assets/logos/l-recis2.jpeg') }}" alt="logo recis" />
            </a>
        </div>
        <div class="col-8 p-0  d-flex align-items-center">
            <div class="d-inline-block pl-5 font-weight-bold text-white sm-title-3" style="height: fit-content">
                <span class="d-block text-uppercase">Rencontres</span>
                <span class="d-block text-uppercase">Cinématographiques</span>
                <span class="d-block text-uppercase">de Sya (RECIS)</span>
                <span class="d-block text-uppercase">1er ÉDITION DU 6 au 10 décembre 2022</span>
            </div>
        </div>
    </div>
</div>
<header class="sticky-top bg-white">
    <nav class="navbar navbar-expand-lg navbar-white sticky-top">
        <!-- Brand -->
        <a id="ic-recis" class="navbar-brand-2 py-0" href="{{ route('accueil') }}">
            <img src="{{ asset('assets/logos/ic-recis.png') }}" alt="logo recis" />
        </a>
        <!-- Toggler/collapsibe Button -->
        <button class="navbar-toggler custom-toggler ml-auto" type="button" data-toggle="collapse"
            data-target="#collapsibleNavbar">
            <span class="navbar-toggler-icon"></span>
        </button>

        <!-- Navbar links -->
        <div class="collapse navbar-collapse " id="collapsibleNavbar">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="{{ route('accueil') }}">accueil</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="{{ route('recis') }}">recis</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="{{ route('evenement') }}">événements</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="{{ route('photo') }}">photos</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="{{ route('contact') }}">Contact</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="{{ "#"/*route('submission') */}}">film submission</a>
                </li>
                @guest
                    @if (!Route::has('login'))
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('login') }}">{{ __('Login') }}</a>
                        </li>
                    @endif

                    @if (!Route::has('register'))
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('register') }}">{{ __('Register') }}</a>
                        </li>
                    @endif
                @else
                    <li class="nav-item dropdown">
                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button"
                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            {{ Auth::user()->name }}
                        </a>
                        <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="{{ route('admin') }}">admin</a>
                            <a class="dropdown-item" href="{{ route('logout') }}" onclick="event.preventDefault();
                                                                 document.getElementById('logout-form').submit();">
                                Se déconnecter
                            </a>

                            <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                                @csrf
                            </form>
                        </div>
                    </li>
                @endguest
            </ul>
        </div>
    </nav>
</header>
